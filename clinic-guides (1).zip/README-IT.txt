Clinic Equipment Quick Guides - static website
==============================================

Contents: 16 static HTML files (no server-side code, no database, no build step).

  index.html               - list of all guides
  abr-navigator.html       - Natus Bio-logic Navigator Pro (ABR)
  abr-vivosonic.html       - Vivosonic Integrity (ABR, 1-channel)
  oae-capella-noah.html      - Madsen Capella OAE via NOAH 3 / OAE SYSTEM
  oae-madsen-capella.html  - Madsen Capella2 OAE (PC-based)
  vng-visualeyes.html      - Interacoustics VisualEyes (VNG)
  vhit-ics-impulse.html    - Natus ICS Impulse (vHIT)
  caloric-airfx.html       - Interacoustics Air Fx caloric irrigator
  audiometer-astera.html     - Madsen Astera audiometer (OTOsuite)
  audiometer-harp.html     - Inventis Harp audiometer
  audiometer-ac40.html     - Interacoustics AC40 audiometer
  tympanometer-clarinet.html - Inventis Clarinet tympanometer
  tympanometer-zodiac.html   - MADSEN Zodiac 901 tympanometer
  audiometer-piano-vra.html  - Inventis Piano audiometer + pediatric VRA (Maestro) - pediatric clinic
  audiometer-piano-standalone.html - Inventis Piano audiometer, stand-alone (no PC) - adult clinic
  rem-aurical-freefit.html   - Natus Aurical FreeFit real-ear measurement

How to publish:
  1. Upload all files into ONE folder on any web server (e.g. /guides/).
  2. Pages must be reachable WITHOUT login (students open them by scanning a QR code).
  3. HTTPS is recommended.
  4. Send back the final URL of each page, e.g.
       https://example.ac.ir/guides/abr-navigator.html
     QR code labels will be generated for these exact URLs.
     Please keep the file names and URLs stable after printing the labels.

Fonts:
  Pages load the "Vazirmatn" font from fonts.googleapis.com. If Google Fonts
  is slow or blocked on the network, the pages fall back to Tahoma and still
  work. Optional: self-host Vazirmatn (OFL license) and replace the
  <link href="https://fonts.googleapis.com/..."> line in each file.

No cookies, no tracking, no external scripts.
